sap.ui.define([
	"nument21.apps./orders/test/unit/controller/Master.controller"
], function () {
	"use strict";
});
