sap.ui.define([
	"customer/test/unit/controller/Master.controller"
], function () {
	"use strict";
});
